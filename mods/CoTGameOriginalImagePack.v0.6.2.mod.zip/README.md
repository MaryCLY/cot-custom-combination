
# CoTGameOriginalImagePack

CoT v0.5.5版本图片包

load this mod in the last .


---

use bootJsonFillTool to generate boot.json

```
node "<To bootJsonFillTool.js>" "<To bootTemplate.json>" "<To img dir>" "<Game Version>"
```

example :

```shell
node ".\dist-tools\bootJsonFillTool.js" "bootTemplate.json" "img" "0.5.0.3"
```
